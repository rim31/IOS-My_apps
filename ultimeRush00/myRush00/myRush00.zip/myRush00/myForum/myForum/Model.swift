//
//  Model.swift
//  myForum
//
//  Created by Olivier SENG on 6/17/17.
//  Copyright © 2017 OS. All rights reserved.
//

import Foundation

struct donnees { //tableau de tuple          		static accessible patout
    
    static var myInfos : [[String: String]] = [
        ["image": "https://cdn.intra.42.fr/users/medium_oseng.jpg", "login": "oseng", "date": "30 juin 2017", "title":"hadoken"],
        ["image": "https://cdn.intra.42.fr/users/medium_svelhinh.jpg", "login": "svelhin", "date": "1 juin 2020", "title":"lopette"],
        ["image": "https://cdn.intra.42.fr/users/medium_eozdek.jpg", "login": "eozdek", "date": "1 juin 3990", "title":"tibo inshape"]
    ]
    
    
    
}

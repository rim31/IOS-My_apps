//
//  topicsTableViewCell.swift
//  myForum
//
//  Created by Olivier SENG on 6/17/17.
//  Copyright © 2017 OS. All rights reserved.
//

import UIKit

class topicsTableViewCell: UITableViewCell {

    @IBOutlet weak var auteur: UILabel!
    @IBOutlet weak var dateTopic: UILabel!
    @IBOutlet weak var titreTopic: UILabel!
    @IBOutlet weak var photo: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
